#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
Adafruit_PWMServoDriver p1(0x40),p2(0x44),p3(0x42);
void setup(){p1.begin();p2.begin();p3.begin();p1.setPWMFreq(50);p2.setPWMFreq(50);p3.setPWMFreq(50);}
void loop(){
  // Add the seven-segment servo mapping here.
  // Recommended: move one servo at a time with a safe gap.
  delay(1000);
}
