GSN CREATIONS — Mechanical 7-Segment Display

Category: Servo

This package contains:
- mechanical_7segment.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
