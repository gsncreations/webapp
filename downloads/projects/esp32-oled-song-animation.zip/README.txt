GSN CREATIONS — ESP32 OLED Song Animation

Category: ESP32

This package contains:
- GSN_OLED_Animation_Player.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
