#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C
#define MQ_PIN 34
Adafruit_SSD1306 display(SCREEN_WIDTH,SCREEN_HEIGHT,&Wire,-1);
void setup(){display.begin(SSD1306_SWITCHCAPVCC,OLED_ADDR);}
void loop(){
  int value=analogRead(MQ_PIN);
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1);
  display.setCursor(5,10); display.println("MQ SENSOR");
  display.setCursor(5,30); display.print("RAW: "); display.println(value);
  display.display(); delay(250);
}
