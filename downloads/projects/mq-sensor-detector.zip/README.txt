GSN CREATIONS — MQ Sensor Detector

Category: Sensors

This package contains:
- mq_sensor_detector.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
