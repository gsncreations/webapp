#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C
#define BUTTON_PIN 4
Adafruit_SSD1306 display(SCREEN_WIDTH,SCREEN_HEIGHT,&Wire,-1);
void setup(){pinMode(BUTTON_PIN,INPUT_PULLUP);display.begin(SSD1306_SWITCHCAPVCC,OLED_ADDR);}
void loop(){
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1);
  display.setCursor(5,10); display.println("GSN DINO");
  display.setCursor(5,30); display.println(digitalRead(BUTTON_PIN)==LOW?"JUMP!":"RUN...");
  display.display(); delay(40);
}
