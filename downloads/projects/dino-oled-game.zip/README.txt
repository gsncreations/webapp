GSN CREATIONS — DINO OLED Game

Category: ESP32

This package contains:
- dino_oled_game.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
