#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C
#define FLAME_PIN 2
#define BUZZER_PIN 8
Adafruit_SSD1306 display(SCREEN_WIDTH,SCREEN_HEIGHT,&Wire,-1);
void setup(){
  pinMode(FLAME_PIN,INPUT);
  pinMode(BUZZER_PIN,OUTPUT);
  display.begin(SSD1306_SWITCHCAPVCC,OLED_ADDR);
}
void loop(){
  bool fire=digitalRead(FLAME_PIN);
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.setTextSize(2); display.setCursor(10,20);
  display.println(fire?"FIRE!":"SAFE");
  display.display(); digitalWrite(BUZZER_PIN,fire?HIGH:LOW); delay(100);
}
