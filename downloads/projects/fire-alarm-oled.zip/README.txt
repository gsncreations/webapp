GSN CREATIONS — Fire Alarm with OLED

Category: Arduino

This package contains:
- fire_alarm_oled.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
