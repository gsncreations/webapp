GSN CREATIONS — Solar Tracking Prototype

Category: Solar

This package contains:
- solar_tracker.ino
- circuit.svg

Use the full project page for the component list, connections, working process and scope.
Always verify pin assignments against the exact hardware before powering the project.
