#include <Servo.h>
Servo tracker;
#define LEFT_SENSOR A0
#define RIGHT_SENSOR A1
#define SERVO_PIN 9
void setup(){tracker.attach(SERVO_PIN);}
void loop(){
  int left=analogRead(LEFT_SENSOR), right=analogRead(RIGHT_SENSOR);
  int pos=tracker.read();
  if(left>right+20) pos++;
  if(right>left+20) pos--;
  pos=constrain(pos,0,180);
  tracker.write(pos); delay(100);
}
